for(let i=0;i<10;i++)
{
    if(i===3)
    {
        continue;
    }
    
    document.write(i);

}