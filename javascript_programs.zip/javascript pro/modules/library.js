 let message="ES6 model";


function user(name)
{
     return console.log(`hello ${name}`);
}


 class test
{
    constructor()
    {
        console.log("constructor method");
    }
}


export{message,user, test}