var element;

element= document.getElementById("header").innerHTML="<h1>chaging text</h1>";

// element= document.getElementById("header").attributes[1].value="pqr";



element= document.getElementById("header").removeAttribute("style")

element= document.getElementById("header").getAttribute("class");
// element= document.getElementById("header").innerHTML;

console.log(element);