import {message,user,test} from "./library.js";



console.log(message);


console.log(user("simplilearn"));


let a= new test();