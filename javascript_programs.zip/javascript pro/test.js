/*document.write("<b>this is external javascript<br></b>");
document.write("<i>javascript demo<br></i>");*/
document.write("this is my code!!!");